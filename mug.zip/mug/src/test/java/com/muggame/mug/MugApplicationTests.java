package com.muggame.mug;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MugApplicationTests {

	@Test
	void contextLoads() {
	}

}
